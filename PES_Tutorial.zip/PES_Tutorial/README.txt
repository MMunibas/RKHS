Follow the steps given in the SI and manually execute each step or

open a terminal and type
$ chmod +x run_tutorial.sh
$ ./run_tutorial.sh

to automatically execute all example codes. If you have trouble with the compilation, most likely you do not have gfortran installed. If gfortran is not installed, go to each folder and change the line

F90 = gfortran #CHOOSE YOUR FORTRAN COMPILER HERE

in the Makefile to the compiler of your choice. The codes should run now.

To compile the code for each individual step, simply cd into the respective folder and execute
$ make