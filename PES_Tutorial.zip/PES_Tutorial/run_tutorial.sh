#!/bin/bash

#Step 1
echo 'generating reference "ab initio" data...'
cd step1_generation_of_reference_data
make
./gendata.x
cp *.csv ../step2_construction_of_kernel_interpolations/.
cd ..
echo 'done!'
echo 

#Step 2
echo 'constructing kernel interpolations...'
cd step2_construction_of_kernel_interpolations
make
./constructkernels.x
cp *.kernel ../step3_evaluating_pes/.
cd ..
echo 'done!'
echo

#Step3 
echo 'testing evaluation of kernel-based PES...'
cd step3_evaluating_pes
make
./evaluatepes.x
cd ..
echo 'done!'
echo
